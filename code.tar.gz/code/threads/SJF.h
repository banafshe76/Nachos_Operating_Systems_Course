#ifndef SJF_H
#define SJF_H

#include "scheduler.h"

class SJF : public Scheduler
{
public:
	void setToTime();
	Thread *FindNextToRun();
};

#endif // SJF_H
