#include "priority.h"

#include "copyright.h"
#include "system.h"
#include <iostream>


void Priority::ReadyToRun (Thread *thread)///////////////////////////////////////////////////////////////////////////////////bbbbbb
{
    DEBUG('t', "Putting thread %s on ready list.\n", thread->getName());

    thread->setStatus(READY);
    readyList->SortedInsert((void *)thread,thread->priority*(-1));//////////////////////////////////bbbbbbbbbbb
}
