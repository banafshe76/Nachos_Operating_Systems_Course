
#include "multiLevelQueue.h"

#include "copyright.h"
#include "system.h"
#include <iostream>

void MultiLevelQueue::setToTime(){
	currentThread->totalTime = time(0) - currentThread->startTime  ;
	std::cout<<"ThreadName:    "<<currentThread->getName()<<"\ntotalTime\n"<<currentThread->totalTime<<"\n";

}

void
MultiLevelQueue::ReadyToRun2(Thread *thread)
{
    DEBUG('t', "Putting thread %s on ready list.\n", thread->getName());

    thread->setStatus(READY);
    if (counter%2 == 0){
		readyList->SortedInsert((void *)thread, thread->totalTime);
		counter++;
	}
	else if (counter%2 == 1){
		otherList->SortedInsert((void *)thread, thread->priority*(-1));
		counter++;
	}

}

void
MultiLevelQueue::ReadyToRun (Thread *thread)
{
    DEBUG('t', "Putting thread %s on ready list.\n", thread->getName());

    thread->setStatus(READY);
    readyList->SortedInsert((void *)thread, thread->measure);
}

Thread* MultiLevelQueue::FindNextToRun ()
{
	if( currentThread->totalTime == 0)
		setToTime();
	else if(b){	
		std::cout<<"here\n";
		//(Thread *)readyList->Remove();		
		halfFunc();
		b = 0;			
	} 
		return (Thread *)readyList->Remove();
    
}

void MultiLevelQueue::halfFunc()
{


	List *ex = new List;
	int i=1;
	while(!readyList->IsEmpty()){
	void * t = readyList->Remove();
	ex->SortedInsert(t, ((Thread*)t)->totalTime);}

	List *ey = new List;
	while(!otherList->IsEmpty()){
	void * t = otherList->Remove();
	ex->SortedInsert(t, ((Thread*)t)->priority);
	//std::cout <<"PPPPP"<<((Thread*)t)->priority<<"\n";
	}
	while(!ex->IsEmpty()){
	void * t = ex->Remove();
	((Thread*)t)->measure=i;
	readyList->Append(t);
	i++;}
	while(!ey->IsEmpty()){
	void * t = ey->Remove();
	((Thread*)t)->measure=i;
	readyList->Append(t);
	i++;}
}
