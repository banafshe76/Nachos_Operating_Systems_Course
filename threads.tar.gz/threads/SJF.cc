#include "SJF.h"

#include "copyright.h"
#include "system.h"
#include <iostream>

void SJF::setToTime(){
	currentThread->totalTime = time(0) - currentThread->startTime  ;
	std::cout<<"ThreadName:    "<<currentThread->getName()<<"\ntotalTime\n"<<currentThread->totalTime<<"\n";

}


Thread* SJF::FindNextToRun ()
{
	if( currentThread->totalTime == 0)
		setToTime();
    return (Thread *)readyList->Remove();
    
}
