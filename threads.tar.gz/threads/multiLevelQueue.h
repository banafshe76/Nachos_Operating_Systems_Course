#ifndef MULTILEVELQUEUE_H
#define MULTILEVELQUEUE_H


#include "scheduler.h"

class MultiLevelQueue : public Scheduler
{
	public:
		void ReadyToRun2 (Thread *thread);
		void ReadyToRun (Thread *thread);
		void setToTime();
		Thread* FindNextToRun ();
		void halfFunc();
};

#endif //MULTILEVELQUEUE_H
