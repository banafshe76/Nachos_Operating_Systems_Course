#ifndef PRIORITY_H
#define PRIORITY_H

#include "scheduler.h"

class Priority : public Scheduler
{
public:
	void ReadyToRun (Thread *thread);
};

#endif // PRIORITY_H
